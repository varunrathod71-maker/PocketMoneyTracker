package com.stickflicks.pocketmoney;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    final int BG=Color.rgb(3,18,17), PANEL=Color.rgb(8,37,34), PANEL2=Color.rgb(10,48,43),
        GREEN=Color.rgb(35,220,163), MINT=Color.rgb(113,255,194), WHITE=Color.rgb(230,250,244),
        MUTED=Color.rgb(145,179,169), RED=Color.rgb(255,111,119), GOLD=Color.rgb(255,193,66);
    LinearLayout root, body, nav;
    JSONArray txns = new JSONArray(), goals = new JSONArray();
    String page="Home", txnFilter="All";
    android.content.SharedPreferences prefs;
    TextView balanceView, incomeView, expenseView;
    @Override public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("pocket",MODE_PRIVATE); load(); showPage("Home");}
    void load(){try{txns=new JSONArray(prefs.getString("txns","[]"));goals=new JSONArray(prefs.getString("goals","[]"));}catch(Exception e){txns=new JSONArray();goals=new JSONArray();}}
    void save(){prefs.edit().putString("txns",txns.toString()).putString("goals",goals.toString()).apply();}
    GradientDrawable shape(int color,int radius,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(stroke>0)d.setStroke(1,stroke);return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,bold?Typeface.BOLD:Typeface.NORMAL);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(a,a,a,a);}
    void gap(LinearLayout l,int h){View v=new View(this);l.addView(v,new LinearLayout.LayoutParams(1,h));}
    TextView button(String label,Runnable action){TextView t=text(label,14,WHITE,true);t.setGravity(Gravity.CENTER);t.setPadding(14,13,14,13);t.setBackground(shape(PANEL2,18,Color.rgb(19,102,83)));t.setOnClickListener(v->action.run());return t;}
    void showPage(String p){page=p; root=column();root.setBackgroundColor(BG);setContentView(root);
        LinearLayout top=row();top.setPadding(20,18,20,12);
        TextView logo=text("▣",30,GREEN,true);top.addView(logo);LinearLayout title=column();TextView name=text("Pocket Money",19,WHITE,true);TextView sub=text("TRACKER  •  ₹",10,MUTED,true);title.addView(name);title.addView(sub);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=12;top.addView(title,tp);
        top.addView(button("⚙",()->showPage("Settings")));root.addView(top);
        ScrollView scroll=new ScrollView(this);body=column();body.setPadding(18,8,18,18);scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(p.equals("Home"))home();else if(p.equals("Transactions"))transactions();else if(p.equals("Savings"))savings();else if(p.equals("Reports"))reports();else settings();
        nav=row();nav.setPadding(7,8,7,10);nav.setBackgroundColor(Color.rgb(2,13,13));
        String[] tabs={"Home","Transactions","Savings","Reports"};
        for(String tab:tabs){TextView t=text((p.equals(tab)?"● ":"")+tab,11,p.equals(tab)?GREEN:MUTED,true);t.setGravity(Gravity.CENTER);t.setPadding(3,12,3,12);nav.addView(t,new LinearLayout.LayoutParams(0,-2,1));t.setOnClickListener(v->showPage(tab));}
        root.addView(nav);
    }
    double sum(String kind){double n=0;for(int i=0;i<txns.length();i++){JSONObject o=txns.optJSONObject(i);if(o!=null&&kind.equals(o.optString("kind")))n+=o.optDouble("amount");}return n;}
    String money(double n){return "₹"+new DecimalFormat("#,##0.##").format(n);}
    void home(){
        TextView greet=text("Good day! 👋",22,WHITE,true);body.addView(greet);body.addView(text("Let’s keep your money organised.",13,MUTED,false));gap(body,16);
        LinearLayout card=column();card.setPadding(18,18,18,18);card.setBackground(shape(PANEL,24,Color.rgb(13,91,73)));
        card.addView(text("AVAILABLE BALANCE",11,MINT,true));double bal=sum("Income")-sum("Expense");card.addView(text(money(bal),32,WHITE,true));gap(card,14);
        LinearLayout stats=row();LinearLayout a=column(),b=column();a.addView(text("Money in",12,MUTED,false));a.addView(text(money(sum("Income")),19,GREEN,true));b.addView(text("Money out",12,MUTED,false));b.addView(text(money(sum("Expense")),19,RED,true));stats.addView(a,new LinearLayout.LayoutParams(0,-2,1));stats.addView(b,new LinearLayout.LayoutParams(0,-2,1));card.addView(stats);body.addView(card);
        gap(body,18);body.addView(text("QUICK ADD",12,MUTED,true));gap(body,8);
        LinearLayout quick=row();quick.addView(button("+ Income",()->editTxn(null,"Income")),new LinearLayout.LayoutParams(0,-2,1));View spacer=new View(this);quick.addView(spacer,new LinearLayout.LayoutParams(10,1));quick.addView(button("− Expense",()->editTxn(null,"Expense")),new LinearLayout.LayoutParams(0,-2,1));body.addView(quick);
        gap(body,22);LinearLayout h=row();h.addView(text("Recent transactions",18,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));h.addView(button("See all",()->showPage("Transactions")));body.addView(h);gap(body,8);
        for(int i=txns.length()-1;i>=Math.max(0,txns.length()-5);i--)txnCard(txns.optJSONObject(i),i);
        if(txns.length()==0)empty("No transactions yet","Tap + Income or − Expense to get started.");
    }
    void empty(String a,String b){LinearLayout c=column();c.setPadding(18,25,18,25);c.setGravity(Gravity.CENTER);c.setBackground(shape(PANEL,18,0));c.addView(text(a,17,WHITE,true));TextView s=text(b,12,MUTED,false);s.setGravity(Gravity.CENTER);c.addView(s);body.addView(c);}
    void transactions(){body.addView(text("Transactions",25,WHITE,true));gap(body,10);
        LinearLayout filters=row();for(String f:new String[]{"All","Income","Expense"}){TextView x=button((txnFilter.equals(f)?"✓ ":"")+f,()->{txnFilter=f;showPage("Transactions");});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(2,0,2,0);filters.addView(x,lp);}body.addView(filters);gap(body,10);
        EditText search=new EditText(this);search.setSingleLine(true);search.setHint("Search transactions…");search.setHintTextColor(MUTED);search.setTextColor(WHITE);search.setPadding(14,8,14,8);search.setBackground(shape(PANEL,16,0));body.addView(search);gap(body,10);
        LinearLayout list=column();body.addView(list);Runnable render=()->{list.removeAllViews();String q=search.getText().toString().toLowerCase(Locale.ROOT);int count=0;for(int i=txns.length()-1;i>=0;i--){JSONObject o=txns.optJSONObject(i);if(o==null)continue;String kind=o.optString("kind"),note=o.optString("note");if(!txnFilter.equals("All")&&!txnFilter.equals(kind))continue;if(!note.toLowerCase(Locale.ROOT).contains(q))continue;txnCardInto(list,o,i);count++;}if(count==0){TextView t=text("No matching transactions.",13,MUTED,false);list.addView(t);}};search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){render.run();}public void afterTextChanged(android.text.Editable e){}});render.run();
        gap(body,12);body.addView(button("+ Add transaction",()->editTxn(null,"Expense")));
    }
    void txnCard(JSONObject o,int i){txnCardInto(body,o,i);}
    void txnCardInto(LinearLayout target,JSONObject o,int i){if(o==null)return;LinearLayout c=row();c.setPadding(13,12,13,12);c.setBackground(shape(PANEL,16,0));TextView icon=text(o.optString("kind").equals("Income")?"↗":"↘",22,o.optString("kind").equals("Income")?GREEN:RED,true);icon.setGravity(Gravity.CENTER);c.addView(icon,new LinearLayout.LayoutParams(42,42));LinearLayout info=column();info.addView(text(o.optString("note","Transaction"),14,WHITE,true));info.addView(text(o.optString("date",""),10,MUTED,false));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(0,-2,1);ip.leftMargin=10;c.addView(info,ip);String sign=o.optString("kind").equals("Income")?"+":"−";c.addView(text(sign+money(o.optDouble("amount")),14,o.optString("kind").equals("Income")?GREEN:RED,true));c.setOnClickListener(v->editTxn(o,i));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=7;target.addView(c,cp);}
    void editTxn(JSONObject old,String kind){final EditText amount=new EditText(this),note=new EditText(this);amount.setHint("Amount in ₹");amount.setInputType(8194);note.setHint("What was it for?");note.setSingleLine(true);if(old!=null){amount.setText(""+old.optDouble("amount"));note.setText(old.optString("note"));kind=old.optString("kind");}
        final String[] k={kind};LinearLayout form=column();form.setPadding(8,8,8,0);TextView type=text("Transaction type",13,MUTED,true);form.addView(type);LinearLayout types=row();for(String t:new String[]{"Income","Expense"})types.addView(button((t.equals(k[0])?"✓ ":"")+t,()->{k[0]=t;}),new LinearLayout.LayoutParams(0,-2,1));form.addView(types);form.addView(amount);form.addView(note);
        new AlertDialog.Builder(this).setTitle(old==null?"Add transaction":"Edit transaction").setView(form).setPositiveButton(old==null?"Save":"Update",(d,w)->{try{double n=Double.parseDouble(amount.getText().toString());if(n<=0)throw new Exception();JSONObject o=new JSONObject();o.put("kind",k[0]);o.put("amount",n);o.put("note",note.getText().toString().trim().isEmpty()?(k[0].equals("Income")?"Pocket money":"Expense"):note.getText().toString().trim());o.put("date",new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date()));if(old!=null){txns.put(indexOf(old),o);}else txns.put(o);save();showPage(page);}catch(Exception e){Toast.makeText(this,"Enter a valid amount",Toast.LENGTH_SHORT).show();}}).setNegativeButton("Cancel",null).setNeutralButton(old==null?null:"Delete",(d,w)->{if(old!=null){removeTxn(old);save();showPage(page);}}).show();}
    int indexOf(JSONObject target){for(int i=0;i<txns.length();i++)if(txns.optJSONObject(i)==target)return i;return -1;}
    void removeTxn(JSONObject target){int idx=indexOf(target);if(idx<0)return;JSONArray n=new JSONArray();for(int i=0;i<txns.length();i++)if(i!=idx)n.put(txns.opt(i));txns=n;}
    void savings(){body.addView(text("Savings goals",25,WHITE,true));body.addView(text("Small steps add up.",13,MUTED,false));gap(body,12);body.addView(button("+ Add savings goal",()->addGoal()));gap(body,12);
        for(int i=0;i<goals.length();i++){final int goalIndex=i;JSONObject g=goals.optJSONObject(i);if(g==null)continue;LinearLayout c=column();c.setPadding(16,16,16,16);c.setBackground(shape(PANEL,18,0));c.addView(text("◎  "+g.optString("name"),17,WHITE,true));gap(c,6);double saved=g.optDouble("saved"),target=g.optDouble("target");c.addView(text(money(saved)+" / "+money(target),13,MINT,true));ProgressBar pb=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);pb.setMax(100);pb.setProgress(target<=0?0:(int)Math.min(100,saved/target*100));pb.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));c.addView(pb);gap(c,8);LinearLayout rr=row();rr.addView(button("+ Add money",()->goalProgress(g)),new LinearLayout.LayoutParams(0,-2,1));rr.addView(button("Delete",()->new AlertDialog.Builder(this).setMessage("Delete this goal?").setPositiveButton("Delete",(d,w)->{JSONArray n=new JSONArray();for(int j=0;j<goals.length();j++)if(j!=goalIndex)n.put(goals.opt(j));goals=n;save();showPage("Savings");}).setNegativeButton("Cancel",null).show()),new LinearLayout.LayoutParams(0,-2,1));c.addView(rr);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=10;body.addView(c,lp);}
        if(goals.length()==0)empty("No savings goals yet","Create a goal for something you want to save for.");
    }
    void addGoal(){LinearLayout f=column();EditText n=new EditText(this),t=new EditText(this);n.setHint("Goal name (e.g. Headphones)");t.setHint("Target amount ₹");t.setInputType(8194);f.addView(n);f.addView(t);new AlertDialog.Builder(this).setTitle("New savings goal").setView(f).setPositiveButton("Create",(d,w)->{try{JSONObject o=new JSONObject();o.put("name",n.getText().toString().trim());o.put("target",Double.parseDouble(t.getText().toString()));o.put("saved",0);goals.put(o);save();showPage("Savings");}catch(Exception e){Toast.makeText(this,"Enter a name and valid target",0).show();}}).setNegativeButton("Cancel",null).show();}
    void goalProgress(JSONObject g){EditText e=new EditText(this);e.setHint("Amount to add ₹");e.setInputType(8194);new AlertDialog.Builder(this).setTitle("Add savings progress").setView(e).setPositiveButton("Add",(d,w)->{try{g.put("saved",g.optDouble("saved")+Double.parseDouble(e.getText().toString()));save();showPage("Savings");}catch(Exception ex){Toast.makeText(this,"Enter a valid amount",0).show();}}).setNegativeButton("Cancel",null).show();}
    void reports(){body.addView(text("Reports",25,WHITE,true));gap(body,12);double in=sum("Income"),out=sum("Expense");reportCard("Total income",money(in),GREEN);reportCard("Total expenses",money(out),RED);reportCard("Net balance",money(in-out),MINT);gap(body,14);body.addView(text("Spending overview",18,WHITE,true));gap(body,8);body.addView(text("Money in   "+money(in),14,GREEN,true));body.addView(text("Money out  "+money(out),14,RED,true));body.addView(text("Transactions recorded: "+txns.length(),13,MUTED,false));gap(body,16);body.addView(button("Export transactions as CSV",()->exportCsv()));}
    void reportCard(String label,String value,int color){LinearLayout c=column();c.setPadding(16,14,16,14);c.setBackground(shape(PANEL,16,0));c.addView(text(label,12,MUTED,false));c.addView(text(value,23,color,true));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=8;body.addView(c,lp);}
    void settings(){body.addView(text("Settings",25,WHITE,true));gap(body,12);body.addView(text("Pocket Money Tracker",18,WHITE,true));body.addView(text("Version 1.0 • Offline-first • Data stored on this phone",12,MUTED,false));gap(body,18);body.addView(button("Export transactions as CSV",()->exportCsv()));gap(body,8);body.addView(button("Backup all data (JSON)",()->backupJson()));gap(body,8);body.addView(button("Clear all app data",()->new AlertDialog.Builder(this).setMessage("This permanently deletes transactions and goals on this phone. Continue?").setPositiveButton("Clear",(d,w)->{txns=new JSONArray();goals=new JSONArray();save();showPage("Home");}).setNegativeButton("Cancel",null).show()));}
    void exportCsv(){StringBuilder s=new StringBuilder("Type,Amount,Note,Date\n");for(int i=0;i<txns.length();i++){JSONObject o=txns.optJSONObject(i);if(o!=null)s.append(o.optString("kind")).append(",").append(o.optDouble("amount")).append(",\"").append(o.optString("note").replace("\"","\"\"")).append("\",").append(o.optString("date")).append("\n");}share("Pocket Money Tracker.csv",s.toString(),"text/csv");}
    void backupJson(){JSONObject o=new JSONObject();try{o.put("transactions",txns);o.put("goals",goals);}catch(Exception e){}share("Pocket Money Tracker backup.json",o.toString(2),"application/json");}
    void share(String name,String content,String type){Intent i=new Intent(Intent.ACTION_SEND);i.setType(type);i.putExtra(Intent.EXTRA_SUBJECT,name);i.putExtra(Intent.EXTRA_TEXT,content);startActivity(Intent.createChooser(i,"Export Pocket Money data"));}
}
