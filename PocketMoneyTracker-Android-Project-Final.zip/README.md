# Pocket Money Tracker (Android)

Native Android app in Java with an offline-first local data store.

## Build with GitHub Actions
1. Upload this entire ZIP to a new GitHub repository (extract it first so `settings.gradle` is at repository root).
2. Add the included workflow at `.github/workflows/android.yml`.
3. Open the repository's **Actions** tab and run **Build Pocket Money Tracker APK**.
4. Download the `PocketMoneyTracker-debug-apk` artifact from the successful workflow run.

## App features
- Dark emerald-green UI
- Income and expense totals and balance
- Add, edit, and delete transactions
- Income/expense filters and transaction search
- Savings goals with progress
- Summary reports and CSV/JSON export
- Local SharedPreferences storage; no account required

A built-in vector wallet icon is wired to the Android launcher. It is an approximation of the provided reference artwork; the original raster image was not available as a separate file in this project.
